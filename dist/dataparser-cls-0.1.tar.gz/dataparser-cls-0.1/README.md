# dataParseClassification
Data parser for classification
